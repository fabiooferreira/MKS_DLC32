@echo off
chcp 65001 >nul
py -3.12 "%~dp0Fabricação Fresa Laser.py"
pause
