@echo off
py -3.12 -m pip install pyserial==3.5 pillow==11.3.0
pause
