@echo off
py -3.12 "%~dp0Instalador_CNC_FFST_S3.py"
pause
