/*
  stream_file.h - stream redirector for file input

  Part of grblHAL

  Copyright (c) 2024-2026 Terje Io

  grblHAL is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  grblHAL is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with grblHAL. If not, see <http://www.gnu.org/licenses/>.
*/

#pragma once

#include "vfs.h"
#include "core_handlers.h"

void stream_redirect_close (vfs_file_t *file);
void stream_reposition (vfs_file_t *file, size_t pos, line_number_t line_number);
vfs_file_t *stream_redirect_read (const char *filename, status_message_ptr status_handler, on_file_end_ptr eof_handler);
