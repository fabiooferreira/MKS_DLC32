//
// etag.c -
//
// v0.1 / 2026-01-26 / Io Engineering / Terje
//

/*

Copyright (c) 2026, Terje Io
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
list of conditions and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright notice, this
list of conditions and the following disclaimer in the documentation and/or
other materials provided with the distribution.

* Neither the name of the copyright holder nor the names of its contributors may
be used to endorse or promote products derived from this software without
specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

#include "driver.h"

#if ETHERNET_ENABLE || WIFI_ENABLE

#include "sha1.h"
#include "base64.h"

char *etag_create (char *path, struct tm *modified)
{
/*
    static char etag[31];

    if(hal.driver_cap.rtc_set) {

        SHA1_CTX ctx;
        size_t len;
        BYTE sha1sum[SHA1_BLOCK_SIZE];

        sha1_init(&ctx);
        strcpy(etag, strtoisodt(modified));
        sha1_update(&ctx, (BYTE *)etag, strlen(etag));
        sha1_final(&ctx, sha1sum);
        len = base64_encode((BYTE *)sha1sum, (BYTE *)etag + 1, SHA1_BLOCK_SIZE, 0);
        *etag = '"';
        *(etag + ++len) = '"';
        *(etag + ++len) = '\0';
    }

    return hal.driver_cap.rtc_set ? etag : NULL;
*/
    return NULL;
}

#endif
