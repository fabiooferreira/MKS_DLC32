/*

  tcp.h - a lightweight ModBus TCP implementation

  Part of grblHAL

  Copyright (c) 2023-2026 Terje Io

  grblHAL is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  grblHAL is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with grblHAL. If not, see <http://www.gnu.org/licenses/>.

*/

#pragma once
#pragma pack(push, 1)

#include "grbl/modbus.h"

typedef struct {
    uint16_t length;
    uint8_t uid;
    uint8_t code;
    uint8_t data[MODBUS_MAX_ADU_SIZE];
} modbus_tcp_pdu_t;

typedef struct {
    uint16_t tid;
    uint16_t pid;
    modbus_tcp_pdu_t pdu;
} modbus_tcp_adu_t;

#pragma pack(pop)
