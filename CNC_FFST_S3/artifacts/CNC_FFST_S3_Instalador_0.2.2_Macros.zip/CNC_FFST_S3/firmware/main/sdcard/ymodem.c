/*
  ymodem.c - simple file transfer protocol

  Part of SDCard plugin for grblHAL

  Specification: http://wiki.synchro.net/ref:ymodem

  NOTE: Receiver does not send initial 'C' to start transfer.
        Start transfer by sending SOH or STX.

  Copyright (c) 2021-2026 Terje Io

  grblHAL is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  grblHAL is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with grblHAL. If not, see <http://www.gnu.org/licenses/>.
*/

#include "sdcard.h"

#if FS_ENABLE & FS_YMODEM

#include <stdlib.h>
#include <string.h>

#include "grbl/crc.h"
#include "grbl/task.h"
#include "grbl/vfs.h"

typedef enum {
    YModem_NOOP = 0,
    YModem_ACK,
    YModem_ACKFile,
    YModem_NoFile,
    YModem_Purge,
    YModem_NAK,
    YModem_EOT,
    YModem_CAN
} ymodem_status_t;

typedef ymodem_status_t (*process_data_ptr)(uint8_t c);

static struct {
    vfs_file_t *handle;
    char filename; // First character only
    uint32_t filelength;
    uint32_t received;
    uint16_t crc;
    uint_fast16_t idx;
    uint_fast16_t errors;
    uint_fast16_t packet_len;
    uint8_t packet_num;
    uint32_t next_timeout;
    process_data_ptr process;
    bool seq_inv;
    bool crc_msb;
    bool completed;
    bool repeated;
    bool upload;
    uint8_t payload[1024];
} ymodem;
static struct {
    volatile uint_fast16_t head;
    volatile uint_fast16_t tail;
    bool overflow;
    uint8_t data[2048];
} rx_buffer;

static driver_reset_ptr driver_reset;
static on_execute_realtime_ptr on_execute_realtime;
static on_unknown_realtime_cmd_ptr on_unknown_realtime_cmd;
static enqueue_realtime_command_ptr rt_handler;

static ymodem_status_t await_soh (uint8_t c);
static ymodem_status_t await_packetnum (uint8_t c);
static ymodem_status_t get_payload (uint8_t c);
static ymodem_status_t await_crc (uint8_t c);
static ymodem_status_t await_eot (uint8_t c);
static ymodem_status_t await_ack (uint8_t c);

static int32_t get_char (void)
{
    uint_fast16_t tail = rx_buffer.tail;

    if(tail == rx_buffer.head)
        return SERIAL_NO_DATA;

    int32_t data = (int32_t)rx_buffer.data[tail];
    rx_buffer.tail = BUFNEXT(tail, rx_buffer);

    return data;
}

static ISR_CODE bool ISR_FUNC(put_char)(uint8_t c)
{
    uint16_t next_head = BUFNEXT(rx_buffer.head, rx_buffer);

    if(next_head == rx_buffer.tail)
        rx_buffer.overflow = 1;
    else {
        rx_buffer.data[rx_buffer.head] = c;
        rx_buffer.head = next_head;
    }

    return true;
}

// End transfer handler.
static void end_transfer (uint8_t out)
{
    // Restore input stream and detach protocol loop from foreground process.
    hal.stream.set_enqueue_rt_handler(rt_handler);
    grbl.on_execute_realtime = on_execute_realtime;

    if(ymodem.handle) {
        if(!out && !ymodem.upload)
            vfs_truncate(ymodem.handle, 0);
        vfs_close(ymodem.handle);
        ymodem.handle = NULL;
    }

    if(out) {
        hal.stream.write_char(out);
        if(out == ASCII_ACK)
            hal.stream.write_char('C');
    }
}

// Cancel handler. Waits for second cancel character.
static ymodem_status_t await_cancel (uint8_t c)
{
    if(c == ASCII_CAN)
        end_transfer(ASCII_NUL);
    else
        ymodem.process = ymodem.upload ? await_ack : await_soh;

    return YModem_NOOP;
}

// Purge handler. Sinks incoming characters.
static ymodem_status_t purge (uint8_t c)
{
    return YModem_NOOP;
}

//
// Packet processing (receive)
//

// Start of header handler.
static ymodem_status_t await_soh (uint8_t c)
{
    ymodem_status_t status = YModem_NOOP;

    if(c == ASCII_SOH || c == ASCII_STX) {
        ymodem.idx = ymodem.crc = 0;
        ymodem.crc_msb = ymodem.seq_inv = ymodem.repeated = false;
        ymodem.packet_len = c == ASCII_SOH ? 128 : 1024;
        ymodem.process = await_packetnum; // Set active handler to wait for packet number.
    } else if(c == ASCII_EOT)
        end_transfer(ASCII_ACK);
    else if(c == ASCII_CAN)
        ymodem.process = await_cancel;   // Set active handler to wait for second CAN character.
    else
        status = YModem_Purge;

    return status;
}

// Packet number handler. Reads and validates packet number.
static ymodem_status_t await_packetnum (uint8_t c)
{
    ymodem_status_t status = YModem_NOOP;

    if(ymodem.seq_inv) {
        c ^= 0xFF;
        if((ymodem.repeated = ymodem.packet_num == c - 1))
            c++;
        if(c == ymodem.packet_num)
            ymodem.process = get_payload;   // Set active handler to fetch payload
        else
            status = YModem_Purge;
    } else if(!(ymodem.seq_inv = (c == ymodem.packet_num || ymodem.packet_num == c - 1)))
        status = YModem_Purge;

    return status;
}

static ymodem_status_t await_eot (uint8_t c)
{
    if(c == ASCII_EOT)
        end_transfer(ASCII_ACK);

    return YModem_NOOP;
}

// Payload handler. Saves incoming characters in payload buffer.
static ymodem_status_t get_payload (uint8_t c)
{
    ymodem.payload[ymodem.idx++] = c;

    if(ymodem.idx == ymodem.packet_len)
        ymodem.process = await_crc;

    return YModem_NOOP;
}

// CRC handler. Reads and validates CRC, open file on packet 0 writes payload to file when valid.
static ymodem_status_t await_crc (uint8_t c)
{
    ymodem_status_t status = YModem_NOOP;

    if(!ymodem.crc_msb) {
        ymodem.crc_msb = true;
        ymodem.crc = c;
    } else {

        ymodem.process = await_soh;                                                         // Set active handler to wait for next packet
        ymodem.crc = (ymodem.crc << 8) | c;

        if(ccitt_crc16((const uint8_t *)&ymodem.payload, ymodem.packet_len) != ymodem.crc)  // If CRC invalid
            return YModem_Purge;                                                            // purge input stream and return NAK.

        if(ymodem.packet_num == 0 && ymodem.filename == '\0') { // Open file or end transfer

            const char *data = (const char *)ymodem.payload;

            // If no filename present in payload end transfer by sending ACK else send ACK + C if file could be opened, CAN if not.
            if((status = *data == '\0' ? YModem_NoFile : YModem_ACKFile) == YModem_ACKFile) {

                const char *filename = data;

                ymodem.filename = *filename;        // Save first character of filename
                data += strlen(data) + 1;           // and move pointer to file length.
                if(*data)                           // If have file length
                    ymodem.filelength = atoi(data); // then get it.

                if(ymodem.filename == '\0' || (ymodem.handle = vfs_open(filename, "w")) == NULL)
                    status = YModem_CAN;
            }

            ymodem.packet_num++;

        } else { // Write payload to file

            if(!ymodem.repeated) {
                ymodem.packet_num++;
                ymodem.received += ymodem.packet_len;

                // Trim packet length to match file length if last packet
                if((ymodem.completed = ymodem.filelength && ymodem.received > ymodem.filelength))
                    ymodem.packet_len -= ymodem.received - ymodem.filelength;

                // Write payload
                if(vfs_write(ymodem.payload, ymodem.packet_len, 1, ymodem.handle) == ymodem.packet_len) {
                    status = YModem_ACK;
                    if(ymodem.completed) {
                        ymodem.idx = 0;
                        ymodem.process = await_eot; // Set active handler to wait for end of transfer
                    }
                } else
                    status = YModem_CAN;
            } else
                status = YModem_ACK;
        }
    }

    return status;
}

//
// Packet processing (send)
//

FLASHMEM static void send_packet (void)
{
    uint8_t hdr[3], crc[2];
    uint16_t crc16 = ccitt_crc16((const uint8_t *)&ymodem.payload, ymodem.packet_len);

    hdr[0] = ymodem.packet_len == 128 ? ASCII_SOH : ASCII_STX;
    hdr[1] = ymodem.packet_num & 0xFF;
    hdr[2] = hdr[1] ^ 0xFF;
    crc[0] = crc16 >> 8;
    crc[1] = crc16 & 0xFF;

    hal.stream.write_n(hdr, 3);
    hal.stream.write_n(ymodem.payload, ymodem.packet_len);
    hal.stream.write_n(crc, 2);

    ymodem.process = await_ack;
}

FLASHMEM static ymodem_status_t await_eot_ack (uint8_t c)
{
    switch(c) {

        case ASCII_ACK:
            end_transfer(ASCII_NUL);
            break;

        default:
            hal.stream.write_char(ASCII_EOT);
            break;
    }

    return YModem_NOOP;
}

FLASHMEM static ymodem_status_t await_ack (uint8_t c)
{
    switch(c) {

        case ASCII_ACK:
            if(!ymodem.completed) {
                ymodem.packet_num++;
                ymodem.errors = 0;
                ymodem.packet_len = vfs_read(ymodem.payload, 1024, 1, ymodem.handle);
                if((ymodem.completed = vfs_eof(ymodem.handle)) && !(ymodem.packet_len == 128 || ymodem.packet_len == 1024))
                   memset(ymodem.payload + ymodem.packet_len, 0, 1024 - ymodem.packet_len);
                ymodem.packet_len = ymodem.packet_len < 128 ? 128 : 1024;
                send_packet();
            } else {
                hal.stream.write_char(ASCII_EOT);
                ymodem.process = await_eot_ack;
            }
            break;

        case ASCII_NAK:
            if(hal.stream.reset_write_buffer)
                hal.stream.reset_write_buffer();
            if(++ymodem.errors > 10)
                end_transfer(ASCII_NUL);
            else
                send_packet();
            break;

        case ASCII_CAN:
            if(hal.stream.reset_write_buffer)
                hal.stream.reset_write_buffer();
            ymodem.process = await_cancel;
            break;
    }

    return YModem_NOOP;
}

FLASHMEM static ymodem_status_t await_start (uint8_t c)
{
    if(c == 'C') {
        ymodem.process = await_ack;
        send_packet();
    }

    return YModem_NOOP;
}

// End of packet processing.

// Main YModem protocol loop.
// Reads characters off input stream and dispatches them to the appropriate handler.
// Handles timeouts.
static void protocol_loop (sys_state_t state)
{
    int16_t c;

    if(hal.get_elapsed_ticks() >= ymodem.next_timeout) {

        ymodem.next_timeout = hal.get_elapsed_ticks() + 1000;

        ymodem.errors++;
        if(ymodem.errors > 10)
            end_transfer(ASCII_NUL);
        else if(!ymodem.upload) {
            ymodem.process = await_soh;
            hal.stream.write_char(ASCII_NAK);
        }
    }

    while((c = get_char()) != SERIAL_NO_DATA) {

        ymodem.next_timeout = hal.get_elapsed_ticks() + 1000;

        switch(ymodem.process(c)) {

            case YModem_ACK:
                ymodem.errors = 0;
                hal.stream.write_char(ASCII_ACK);
                break;

            case YModem_ACKFile:
                ymodem.errors = 0;
                hal.stream.write_char(ASCII_ACK);
                hal.stream.write_char('C');
                break;

            case YModem_NoFile:
                hal.stream.write_char(ASCII_ACK);
                end_transfer(ASCII_NUL);
                break;

            case YModem_NAK:
                ymodem.errors++;
                hal.stream.write_char(ASCII_NAK);
                break;

            case YModem_CAN:
                hal.stream.write_char(ASCII_CAN);
                hal.stream.write_char(ASCII_CAN);
                end_transfer(ASCII_NUL);
                break;

            case YModem_Purge:
                ymodem.errors++;
                ymodem.process = purge;
                hal.stream.cancel_read_buffer();
                break;

            default:
                break;
        }

        if(grbl.on_execute_realtime != protocol_loop)
            break;
    }

    on_execute_realtime(state);
}

// Terminate any ongoing transfer on a soft reset.
static void on_soft_reset (void)
{
    if(grbl.on_execute_realtime == protocol_loop) {
        hal.stream.write_char(ASCII_CAN);
        hal.stream.write_char(ASCII_CAN);
        end_transfer(ASCII_NUL);
    }

    driver_reset();
}

FLASHMEM static void redirect (process_data_ptr handler, vfs_file_t *file)
{
    rx_buffer.head = rx_buffer.tail = 0;
    rt_handler = hal.stream.set_enqueue_rt_handler(put_char);   // Buffer stream input for YModem protocol

    on_execute_realtime = grbl.on_execute_realtime;             // Add YModem protocol loop
    grbl.on_execute_realtime = protocol_loop;                   // to grblHAL foreground process

    memset(&ymodem, 0, sizeof(ymodem));                         // Init YModem variables
    ymodem.process = handler;
    ymodem.upload = !!(ymodem.handle = file);
    ymodem.next_timeout = hal.get_elapsed_ticks() + 1000;
}

// Check input stream for file YModem start of header (soh) characters.
// Redirect input stream and start download handler when found.
static bool trap_initial_soh (char c)
{
    if(c == ASCII_SOH || c == ASCII_STX) {
        redirect(await_soh, NULL);
        put_char(c);
        return true;                                                // Return true to drop character
    }

    return on_unknown_realtime_cmd == NULL || on_unknown_realtime_cmd(c);
}

FLASHMEM static status_code_t upload (sys_state_t state, char *args)
{
    vfs_stat_t st;
    vfs_file_t *file;
    status_code_t retval = Status_OK;

    if(!(state == STATE_IDLE || state == STATE_CHECK_MODE))
        retval = Status_SystemGClock;
    else if(args && vfs_stat(args, &st) == 0 && !st.st_mode.directory && (file = vfs_open(args, "rb"))) {
        redirect(await_start, file); // Init YModem variables
        strcpy((char *)ymodem.payload, args);
        char *len = strcpy(strchr((char *)ymodem.payload, '\0') + 1, uitoa(st.st_size));
        ymodem.packet_len = len + strlen(len) + 1 - (char *)ymodem.payload > 128 ? 1024 : 128;
    } else
        retval = Status_FileOpenFailed;

    return retval;
}

// Add YModem protocol to chain of unknown real-time command handlers
FLASHMEM void ymodem_init (void)
{
    PROGMEM static const sys_command_t ymodem_command_list[] = {
        {"YUP", upload, {}, { .str = "$YUP=<filename> - upload file with YMODEM" } },
    };

    static sys_commands_t ymodem_commands = {
        .n_commands = sizeof(ymodem_command_list) / sizeof(sys_command_t),
        .commands = ymodem_command_list
    };

    driver_reset = hal.driver_reset;
    hal.driver_reset = on_soft_reset;

    on_unknown_realtime_cmd = grbl.on_unknown_realtime_cmd;
    grbl.on_unknown_realtime_cmd = trap_initial_soh;

    system_register_commands(&ymodem_commands);
}

#endif // FS_ENABLE & FS_YMODEM
