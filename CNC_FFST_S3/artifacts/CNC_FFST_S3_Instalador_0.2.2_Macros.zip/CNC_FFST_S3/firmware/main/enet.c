//
// enet.c - lwIP/FreeRTOS TCP/IP stream implementation
//

/*

Copyright (c) 2018-2026, Terje Io
Copyright (c) 2022, @Henrikastro
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
list of conditions and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright notice, this
list of conditions and the following disclaimer in the documentation and/or
other materials provided with the distribution.

* Neither the name of the copyright holder nor the names of its contributors may
be used to endorse or promote products derived from this software without
specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

#include "driver.h"
#include "enet.h"

#if ETHERNET_ENABLE

#include <math.h>
#include <stdio.h>
#include <string.h>

#include "sdkconfig.h"
#include "esp_system.h"
#include "esp_netif.h"
#include "esp_eth.h"
#include "esp_event.h"
#include "esp_log.h"
#include "driver/gpio.h"
#include "driver/spi_master.h"

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#include "lwip/sockets.h"

#include "grbl/report.h"
#include "grbl/nvs_buffer.h"
#include "grbl/task.h"

#include "networking/networking.h"

#define SYSTICK_INT_PRIORITY    0x80
#define ETHERNET_INT_PRIORITY   0xC0

// some defines for old lwIP stack

#ifndef IPADDR_STRLEN_MAX
#define IPADDR_STRLEN_MAX 16
#endif

#ifndef ip4addr_ntoa_r
#define ip4addr_ntoa_r(ipaddr, buf, buflen) ipaddr_ntoa_r(ipaddr, buf, buflen)
#endif

#ifndef INPUT_GPIO_INTERRUPT
#define INPUT_GPIO_INTERRUPT 35
#endif
#ifndef INPUT_GPIO_MISO
#define INPUT_GPIO_MISO 19
#endif
#ifndef INPUT_GPIO_MOSI
#define INPUT_GPIO_MOSI 23
#endif
#ifndef INPUT_GPIO_CS
#define INPUT_GPIO_CS 5
#endif
#ifndef INPUT_GPIO_SCLK
#define INPUT_GPIO_SCLK 18
#endif

//

static bool enet_enabled;
static char if_name[NETIF_NAMESIZE] = "";
static stream_type_t active_stream = StreamType_Null;
static network_settings_t network, ethernet;
static network_services_t services = {0}, allowed_services;
static uint32_t nvs_address;
static uint8_t mac_addr[6] = {0};
static esp_netif_ip_info_t *ip_info = NULL;
static network_flags_t network_status = {};

static networking_get_info wifi_get_info;

static char netservices[NETWORK_SERVICES_LEN] = "";

static inline void set_addr (char *ip, ip4_addr_t *addr)
{
    memcpy(ip, addr, sizeof(ip4_addr_t));
}

static inline void get_addr (esp_ip4_addr_t *addr, char *ip)
{
    memcpy(addr, ip, sizeof(esp_ip4_addr_t));
}

static bool parse_ip4_addr (const char *value, ip4_addr_t *addr)
{
    ip_addr_t parsed;

    if(ipaddr_aton(value, &parsed) != 1 || !IP_IS_V4_VAL(parsed))
        return false;

    *addr = *ip_2_ip4(&parsed);

    return true;
}


static char *enet_ip_address (void)
{
    static char ip[IPADDR_STRLEN_MAX];

    sprintf(ip, IPSTR, IP2STR(&ip_info->ip));

 //   ip4addr_ntoa_r((const ip_addr_t *)&$, ip, IPADDR_STRLEN_MAX);

    return ip;
}

static network_info_t *get_info (const char *interface)
{
    static network_info_t info = {};

    if(interface == if_name) {

        memcpy(&info.status, &network, sizeof(network_settings_t));

        info.interface = (const char *)if_name;
        info.is_ethernet = true;
        info.link_up = network_status.link_up;
        info.mbps = 100;
        info.status.services = services;
        *info.mac = *info.status.ip = *info.status.gateway = *info.status.mask = '\0';

        struct netif *netif = netif_default;

        if(netif) {

            sprintf(info.mac, MAC_FORMAT_STRING, mac_addr[0], mac_addr[1], mac_addr[2], mac_addr[3], mac_addr[4], mac_addr[5]);

            if(network_status.link_up) {
                strcpy(info.status.ip, enet_ip_address());
                ip4addr_ntoa_r(netif_ip_gw4(netif), info.status.gateway, IP4ADDR_STRLEN_MAX);
                ip4addr_ntoa_r(netif_ip_netmask4(netif), info.status.mask, IP4ADDR_STRLEN_MAX);
            }
        }

    #if MQTT_ENABLE
        networking_make_mqtt_clientid(info.mac, info.mqtt_client_id);
    #endif

        return &info;
    } else if(wifi_get_info)
        return(wifi_get_info(interface));

    return NULL;
}

static void status_event_out (void *data)
{
    networking.event(if_name, (network_status_t){ .value = (uint32_t)data });
}

static void status_event_publish (network_flags_t changed)
{
    task_add_immediate(status_event_out, (void *)((network_status_t){ .changed = changed, .flags = network_status }).value);
}

static void lwIPHostTimerHandler (void *arg)
{
    if(services.mask)
        sys_timeout(STREAM_POLL_INTERVAL, lwIPHostTimerHandler, NULL);

#if TELNET_ENABLE
    if(services.telnet)
        telnetd_poll();
#endif
#if WEBSOCKET_ENABLE
    if(services.websocket)
        websocketd_poll();
#endif
#if FTP_ENABLE
    if(services.ftp)
        ftpd_poll();
#endif
}

static void start_services (void *data)
{
#if TELNET_ENABLE
    if(network.services.telnet && !services.telnet)
        services.telnet = telnetd_init(network.telnet_port == 0 ? NETWORK_TELNET_PORT : network.telnet_port);
#endif
#if WEBSOCKET_ENABLE
    if(network.services.websocket && !services.websocket)
        services.websocket = websocketd_init(network.websocket_port == 0 ? NETWORK_WEBSOCKET_PORT : network.websocket_port);
#endif
#if FTP_ENABLE
    if(network.services.ftp && !services.ftp)
        services.ftp = ftpd_init(network.ftp_port == 0 ? NETWORK_FTP_PORT : network.ftp_port);
#endif
#if HTTP_ENABLE
    if(network.services.http && !services.http)
        services.http = httpd_init(network.http_port);
#endif
#if TELNET_ENABLE || WEBSOCKET_ENABLE || FTP_ENABLE
    sys_timeout(STREAM_POLL_INTERVAL, lwIPHostTimerHandler, NULL);
#endif

    if(!network_status.ip_aquired) {
        network_status.ip_aquired = On;
        status_event_publish((network_flags_t){ .ip_aquired = On });
    }
}

/** Event handler for Ethernet events */
static void eth_event_handler (void *arg, esp_event_base_t event_base, int32_t event_id, void *event_data)
{
    switch (event_id) {

        case ETHERNET_EVENT_CONNECTED:
            esp_eth_ioctl(*(esp_eth_handle_t *)event_data, ETH_CMD_G_MAC_ADDR, mac_addr);
            network_status.link_up = On;
            if(network.ip_mode != IpMode_DHCP) {

                static esp_netif_ip_info_t info;

                get_addr(&info.ip, network.ip);
                get_addr(&info.netmask, network.mask);
                get_addr(&info.gw, network.gateway);

                ip_info = &info;
                task_add_immediate(start_services, NULL);
            }
            status_event_publish((network_flags_t){ .link_up = On });
            break;

        case ETHERNET_EVENT_DISCONNECTED:
            ip_info = NULL;
            network_status.link_up = Off;
            status_event_publish((network_flags_t){ .link_up = On });
            break;
/*
        case ETHERNET_EVENT_START:
            break;

        case ETHERNET_EVENT_STOP:
            break;
*/
        default:
            break;
    }
}

/** Event handler for IP_EVENT_ETH_GOT_IP */
static void got_ip_event_handler (void *arg, esp_event_base_t event_base, int32_t event_id, void *event_data)
{
    static esp_netif_ip_info_t info;

    memcpy(&info, &((ip_event_got_ip_t *)event_data)->ip_info, sizeof(esp_netif_ip_info_t));
    ip_info = &info;

    start_services(NULL);
}

bool enet_start (void)
{
    if(!enet_enabled || esp_netif_init() != ESP_OK)
        return false;

    esp_netif_t *eth_netif;

    memcpy(&network, &ethernet, sizeof(network_settings_t));

    ESP_ERROR_CHECK(esp_event_loop_create_default());

    if(network.ip_mode != IpMode_DHCP) {

        esp_netif_ip_info_t static_ip;
        get_addr(&static_ip.ip, network.ip);
        get_addr(&static_ip.gw, network.gateway);
        get_addr(&static_ip.netmask, network.mask);

        const esp_netif_inherent_config_t eth_behav_cfg = {
            .get_ip_event = IP_EVENT_ETH_GOT_IP,
            .lost_ip_event = 0,
            .flags = ESP_NETIF_DHCP_SERVER|ESP_NETIF_FLAG_AUTOUP,
            .ip_info = &static_ip,
            .if_key = "ETH_DHCPS",
            .if_desc = "eth",
            .route_prio = 50
        };

        esp_netif_config_t eth_as_dhcps_cfg = {
            .base = &eth_behav_cfg,
            .stack = ESP_NETIF_NETSTACK_DEFAULT_ETH
        };
        eth_netif = esp_netif_new(&eth_as_dhcps_cfg);

    } else {
        esp_netif_config_t cfg = ESP_NETIF_DEFAULT_ETH();
        eth_netif = esp_netif_new(&cfg);
    }

    ESP_ERROR_CHECK(esp_eth_set_default_handlers(eth_netif));
    ESP_ERROR_CHECK(esp_event_handler_register(ETH_EVENT, ESP_EVENT_ANY_ID, &eth_event_handler, NULL));
    ESP_ERROR_CHECK(esp_event_handler_register(IP_EVENT, IP_EVENT_ETH_GOT_IP, &got_ip_event_handler, NULL));

    eth_mac_config_t mac_config = ETH_MAC_DEFAULT_CONFIG();
    eth_phy_config_t phy_config = ETH_PHY_DEFAULT_CONFIG();
    phy_config.phy_addr = 1;
    phy_config.reset_gpio_num = -1;

    spi_device_handle_t spi_handle = NULL;
    spi_bus_config_t buscfg = {
        .miso_io_num = INPUT_GPIO_MISO,
        .mosi_io_num = INPUT_GPIO_MOSI,
        .sclk_io_num = INPUT_GPIO_SCLK,
        .quadwp_io_num = -1,
        .quadhd_io_num = -1,
    };
    ESP_ERROR_CHECK(spi_bus_initialize(1, &buscfg, 1));

    spi_device_interface_config_t devcfg = {
        .command_bits = 16,
        .address_bits = 8,
        .mode = 0,
        .clock_speed_hz = 23 * 1000 * 1000,
        .spics_io_num = INPUT_GPIO_CS,
        .queue_size = 20
    };
    ESP_ERROR_CHECK(spi_bus_add_device(1, &devcfg, &spi_handle));

    eth_w5500_config_t w5500_config = ETH_W5500_DEFAULT_CONFIG(spi_handle);
    w5500_config.int_gpio_num = INPUT_GPIO_INTERRUPT;
    esp_eth_mac_t *mac = esp_eth_mac_new_w5500(&w5500_config, &mac_config);
    esp_eth_phy_t *phy = esp_eth_phy_new_w5500(&phy_config);
    esp_eth_config_t config = ETH_DEFAULT_CONFIG(mac, phy);
    esp_eth_handle_t eth_handle = NULL;
    
    ESP_ERROR_CHECK(esp_eth_driver_install(&config, &eth_handle));

    if(esp_read_mac(mac_addr, ESP_MAC_ETH) == ESP_OK)
        esp_eth_ioctl(eth_handle, ETH_CMD_S_MAC_ADDR, mac_addr);
    else
        esp_eth_ioctl(eth_handle, ETH_CMD_S_MAC_ADDR, (uint8_t[]){ 0x02, 0x00, 0x00, 0x12, 0x34, 0x56 });

    /* attach Ethernet driver to TCP/IP stack */
    ESP_ERROR_CHECK(esp_netif_attach(eth_netif, esp_eth_new_netif_glue(eth_handle)));
    /* start Ethernet driver state machine */
    ESP_ERROR_CHECK(esp_eth_start(eth_handle));

    netif_index_to_name(1, if_name);
#if LWIP_NETIF_HOSTNAME
    netif_set_hostname(netif_default, network.hostname);
#endif

    network_status.interface_up = On;
    status_event_publish((network_flags_t){ .interface_up = On });

    return true;
}

static status_code_t ethernet_set_ip (setting_id_t setting, char *value)
{
    ip4_addr_t addr;

    if(!parse_ip4_addr(value, &addr))
        return Status_InvalidStatement;

    status_code_t status = Status_OK;

    switch(setting) {

        case Setting_IpAddress:
            set_addr(ethernet.ip, &addr);
            break;

        case Setting_Gateway:
            set_addr(ethernet.gateway, &addr);
            break;

        case Setting_NetMask:
            set_addr(ethernet.mask, &addr);
            break;

        default:
            status = Status_Unhandled;
            break;
    }

    return status;
}

static char *ethernet_get_ip (setting_id_t setting)
{
    static char ip[IPADDR_STRLEN_MAX];

    switch(setting) {

        case Setting_IpAddress:
            ip4addr_ntoa_r((const ip_addr_t *)&ethernet.ip, ip, IPADDR_STRLEN_MAX);
            break;

        case Setting_Gateway:
            ip4addr_ntoa_r((const ip_addr_t *)&ethernet.gateway, ip, IPADDR_STRLEN_MAX);
            break;

        case Setting_NetMask:
            ip4addr_ntoa_r((const ip_addr_t *)&ethernet.mask, ip, IPADDR_STRLEN_MAX);
            break;

        default:
            *ip = '\0';
            break;
    }

    return ip;
}

static status_code_t ethernet_set_services (setting_id_t setting, uint_fast16_t int_value)
{
    ethernet.services.mask = int_value & allowed_services.mask;

    return Status_OK;
}

static uint32_t ethernet_get_services (setting_id_t id)
{
    return (uint32_t)ethernet.services.mask & allowed_services.mask;
}

static const setting_group_detail_t ethernet_groups[] = {
    { Group_Root, Group_Networking, "Networking" }
};

FLASHMEM static bool is_eth_enabled (const setting_detail_t *setting, uint_fast16_t offset)
{
#if WIFI_ENABLE
    if(setting->id == Setting_NetworkServices)
        return enet_enabled && setting_get_int_value(setting_get_details(Setting_WifiMode, NULL), 0) == WiFiMode_NULL;

    return enet_enabled;
#else
    return enet_enabled;
#endif
}

static const setting_detail_t ethernet_settings[] = {
    { Setting_NetworkServices, Group_Networking, "Network Services", NULL, Format_Bitfield, netservices, NULL, NULL, Setting_NonCoreFn, ethernet_set_services, ethernet_get_services, is_eth_enabled, { .reboot_required = On } },
    { Setting_Hostname, Group_Networking, "Hostname", NULL, Format_String, "x(64)", NULL, "64", Setting_NonCore, ethernet.hostname, NULL, is_eth_enabled, { .reboot_required = On } },
    { Setting_IpMode, Group_Networking, "IP Mode", NULL, Format_RadioButtons, "Static,DHCP,AutoIP", NULL, NULL, Setting_NonCore, &ethernet.ip_mode, NULL, is_eth_enabled, { .reboot_required = On } },
    { Setting_IpAddress, Group_Networking, "IP Address", NULL, Format_IPv4, NULL, NULL, NULL, Setting_NonCoreFn, ethernet_set_ip, ethernet_get_ip, is_eth_enabled, { .reboot_required = On } },
    { Setting_Gateway, Group_Networking, "Gateway", NULL, Format_IPv4, NULL, NULL, NULL, Setting_NonCoreFn, ethernet_set_ip, ethernet_get_ip, is_eth_enabled, { .reboot_required = On } },
    { Setting_NetMask, Group_Networking, "Netmask", NULL, Format_IPv4, NULL, NULL, NULL, Setting_NonCoreFn, ethernet_set_ip, ethernet_get_ip, is_eth_enabled, { .reboot_required = On } },
    { Setting_TelnetPort, Group_Networking, "Telnet port", NULL, Format_Int16, "####0", "1", "65535", Setting_NonCore, &ethernet.telnet_port, NULL, is_eth_enabled, { .reboot_required = On } },
#if FTP_ENABLE
    { Setting_FtpPort, Group_Networking, "FTP port", NULL, Format_Int16, "####0", "1", "65535", Setting_NonCore, &ethernet.ftp_port, NULL, is_eth_enabled, { .reboot_required = On } },
#endif
#if HTTP_ENABLE
    { Setting_HttpPort, Group_Networking, "HTTP port", NULL, Format_Int16, "####0", "1", "65535", Setting_NonCore, &ethernet.http_port, NULL, is_eth_enabled, { .reboot_required = On } },
#endif
    { Setting_WebSocketPort, Group_Networking, "Websocket port", NULL, Format_Int16, "####0", "1", "65535", Setting_NonCore, &ethernet.websocket_port, NULL, is_eth_enabled, { .reboot_required = On } }
};

static const setting_descr_t ethernet_settings_descr[] = {
    { Setting_NetworkServices, "Network services to enable. Consult driver documentation for availability." },
    { Setting_Hostname, "Network hostname." },
    { Setting_IpMode, "IP Mode." },
    { Setting_IpAddress, "Static IP address." },
    { Setting_Gateway, "Static gateway address." },
    { Setting_NetMask, "Static netmask." },
    { Setting_TelnetPort, "(Raw) Telnet port number listening for incoming connections." },
#if FTP_ENABLE
    { Setting_FtpPort, "FTP port number listening for incoming connections." },
#endif
#if HTTP_ENABLE
    { Setting_HttpPort, "HTTP port number listening for incoming connections." },
#endif
    { Setting_WebSocketPort, "Websocket port number listening for incoming connections."
                             "NOTE: WebUI requires this to be HTTP port number + 1."
    }
};

static void ethernet_settings_save (void)
{
    hal.nvs.memcpy_to_nvs(nvs_address, (uint8_t *)&ethernet, sizeof(network_settings_t), true);
}

static void ethernet_settings_restore (void)
{
    memset(&ethernet, 0, sizeof(network_settings_t));

    strcpy(ethernet.hostname, NETWORK_HOSTNAME);

    ip4_addr_t addr;

    ethernet.ip_mode = (ip_mode_t)NETWORK_IPMODE;

    if(parse_ip4_addr(NETWORK_IP, &addr))
        set_addr(ethernet.ip, &addr);

    if(parse_ip4_addr(NETWORK_GATEWAY, &addr))
        set_addr(ethernet.gateway, &addr);

#if NETWORK_IPMODE == 0
    if(parse_ip4_addr(NETWORK_MASK, &addr))
        set_addr(ethernet.mask, &addr);
#else
    if(parse_ip4_addr("255.255.255.0", &addr))
        set_addr(ethernet.mask, &addr);
#endif

    ethernet.services.mask = 0;
    ethernet.ftp_port = NETWORK_FTP_PORT;
    ethernet.telnet_port = NETWORK_TELNET_PORT;
    ethernet.http_port = NETWORK_HTTP_PORT;
#if HTTP_ENABLE && NETWORK_WEBSOCKET_PORT == NETWORK_HTTP_PORT
    ethernet.websocket_port = NETWORK_HTTP_PORT + 1;
#else
    ethernet.websocket_port = NETWORK_WEBSOCKET_PORT;
#endif
    ethernet.services.mask = allowed_services.mask;

    hal.nvs.memcpy_to_nvs(nvs_address, (uint8_t *)&ethernet, sizeof(network_settings_t), true);
}

static void ethernet_settings_load (void)
{
    if(hal.nvs.memcpy_from_nvs((uint8_t *)&ethernet, nvs_address, sizeof(network_settings_t), true) != NVS_TransferResult_OK)
        ethernet_settings_restore();

#if HTTP_ENABLE && WEBSOCKET_ENABLE
    if(ethernet.websocket_port == ethernet.http_port)
        ethernet.websocket_port = ethernet.http_port + 1;
#endif

    ethernet.services.mask &= allowed_services.mask;
}

bool enet_init (void)
{
    static setting_details_t setting_details = {
        .groups = ethernet_groups,
        .n_groups = sizeof(ethernet_groups) / sizeof(setting_group_detail_t),
        .settings = ethernet_settings,
        .n_settings = sizeof(ethernet_settings) / sizeof(setting_detail_t),
        .descriptions = ethernet_settings_descr,
        .n_descriptions = sizeof(ethernet_settings_descr) / sizeof(setting_descr_t),
        .save = ethernet_settings_save,
        .load = ethernet_settings_load,
        .restore = ethernet_settings_restore
    };

    enet_enabled = hal.driver_cap.ethernet;

    if((hal.driver_cap.ethernet = !!(nvs_address = nvs_alloc(sizeof(network_settings_t))))) {

        networking_init();

        settings_register(&setting_details);

        wifi_get_info = networking.get_info;
        networking.get_info = get_info;

        allowed_services.mask = networking_get_services_list((char *)netservices).mask;
    }

    return true;
}

#endif // ETHERNET_ENABLE
